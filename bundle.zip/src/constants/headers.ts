export const ACCESS_TOKEN_HEADER_NAME = 'x-gkm-access-token';
