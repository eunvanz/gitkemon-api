export const ACCESS_TOKEN_COOKIE_NAME = 'gkmat';
