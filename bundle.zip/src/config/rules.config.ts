const Rules = {
  contributionBaseDays: 365,
};

export default Rules;
